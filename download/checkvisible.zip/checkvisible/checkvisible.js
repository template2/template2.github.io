document.addEventListener('DOMContentLoaded', function(){
    
    //Define visible check prototype method
    HTMLElement.prototype.visible = function(){
        return this.offsetWidth > 0 && this.offsetHeight > 0;
    };
    let el = document.querySelector('.element');

    //Check with jQuery
    console.log('----------------------- jQuery')
    console.log($(".element:visible").length>0);
    if($(".element:visible").length){
        console.log('Visible');
    }
    
    //Check with vanilla javascript
    console.log('----------------------- javascript')
    let el_prop = window.getComputedStyle(el);
    console.log(el_prop.display);
    console.log(el_prop.visibility);
    console.log(el_prop.opacity);
    console.log(el.visible());
    if(window.getComputedStyle(el).display === "none"){
        console.log('Invisible');
    }

    el.style.visibility = "hidden";//Placing area but invisible

    //Register click event listener
    el.addEventListener('click', function(){
        //No event is fired because visibility is hidden
        document.querySelector('.element').style.visibility = "visible";
        console.log("Click.");// No event is fired
    });

});