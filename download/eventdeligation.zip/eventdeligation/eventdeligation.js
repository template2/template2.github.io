document.addEventListener('DOMContentLoaded', function(){  // Register event listener after DOM loading
    document.querySelector('.menu').addEventListener('click', function(e){ // Register event listener to click the entire menu area
        //find click menu item
        let target = e.target; // element clicked 
        //In order to get the <li> element, which is a UL list item, the method of finding the parent parent is different depending on the tag clicked under the <li>.
        //let clickli = target.tagName == 'A' ? target.parentNode : (target.tagName == 'SPAN' ? target.parentNode.parentNode : target);
        let clickli = target.closest('LI');
        if(clickli){
            //Initialize the currently active menu
            let currentCategory = document.querySelector('.menu li.active');
            if(currentCategory){
                currentCategory.classList.remove('active');
			}
            //Activate the new selection menu
            clickli.classList.add('active');
			console.log(clickli.dataset.menuid);			
            //let pageURL = "/api/page?menuid="+clickli.getAttribute('data-menuid');
			// Get the new page content to be loaded with AJAX.
        }
    });
});