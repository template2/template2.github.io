let banner = {
    rollId: null,
    interval: 2000,
 
    //Initialize Rolling Banner
    rollInit: function (newinterval) {
        if(parseInt(newinterval) > 0){
            this.interval = newinterval;
        }
        //Current banner
        let firstitem = document.querySelector('.rollimgs li');
        if(firstitem){
            firstitem.classList.add('currentroll');
        }
        //Next banner
        let seconditem = document.querySelectorAll('.rollimgs li')[1];
        if(seconditem){
            seconditem.classList.add('nextroll');
        }
        //Previous banner
        document.querySelector('.rollimgs li:last-child').classList.add('prevroll');
        this.rollId = setInterval(this.rollNext, this.interval);//Call rolling interval timer
    },
     
    //Next banner rolling
    rollNext: function () {
        if(document.querySelector('.prevroll')){
            document.querySelector('.prevroll').classList.remove('prevroll');
        }
        if(document.querySelector('.currentroll')){
            document.querySelector('.currentroll').classList.add('prevroll');
            document.querySelector('.currentroll').classList.remove('currentroll');
        }
        if(document.querySelector('.nextroll')){
            document.querySelector('.nextroll').classList.add('currentroll');
            document.querySelector('.nextroll').classList.remove('nextroll');
        }
		//If the next image exists, select it as the next rolling image, if not, the first image is designated as the rolling image
        if(document.querySelector('.currentroll').nextElementSibling){
            document.querySelector('.currentroll').nextElementSibling.classList.add('nextroll');
        }else{
            document.querySelector('.rollimgs li').classList.add('nextroll');
        }
    },
	
	//roll previous banner
	rollPrev: function () {
		if(document.querySelector('.nextroll')){
			document.querySelector('.nextroll').classList.remove('nextroll');
		}
		if(document.querySelector('.currentroll')){
			document.querySelector('.currentroll').classList.add('nextroll');
			document.querySelector('.currentroll').classList.remove('currentroll');
		}
		if(document.querySelector('.prevroll')){
			document.querySelector('.prevroll').classList.add('currentroll');
			document.querySelector ('.prevroll' ).classList.remove('prevroll');
		}else{

		}
		if(document.querySelector('.currentroll').previousElementSibling){
			document.querySelector('.currentroll').previousElementSibling.classList.add('prevroll');
		}else{
			document.querySelector('.rollimgs li:last-child').classList.add('prevroll');
		}
	}	
}
document.addEventListener('DOMContentLoaded', function(){
    banner.rollInit(2000); // Banner rolling every 4 seconds
	
	// forward/backward click event listener
	document.querySelectorAll('.btnmove').forEach(function(item){
		item.addEventListener('click', function(e){
			clearInterval(banner.rollId); // Release the rolling interval
			// distinguish the direction of the arrow
			if(e.target.parentElement.parentElement.classList.contains('prev')){
				document.querySelector('.rollimgs').classList.add('reverse');
				banner.rollPrev();
				banner.rollId = setInterval(banner.rollPrev, banner.interval ); //recall rolling interval
			}else{
				document.querySelector('.rollimgs').classList.remove('reverse');
				banner.rollNext();
				banner.rollId = setInterval(banner.rollNext, banner.interval ); //recall rolling interval
			}
		});
	}); 	
});