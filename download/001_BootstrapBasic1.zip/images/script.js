$(window).scroll(function() {
  if ($(document).scrollTop() > 50) {
    $('nav').addClass('sticky');
  } else {
    $('nav').removeClass('sticky');
  }
});

//비밀글 체크박스 체크 토글 처리
(function(){
	$('.writer-check .lab-secret').on("click", function() {$('.lab-secret .inactive, .lab-secret .active').toggle();});
})();