window.addEventListener('DOMContentLoaded', function(){
    //Control scroll event
    window.addEventListener("scroll", function(event){
        if(document.querySelector('.progressbar') != null)setProgress();
    });
});
 
function setProgress() {          
    let currY = document.documentElement.scrollTop;//Height of scrolled
    let totalY = document.documentElement.scrollHeight - document.documentElement.clientHeight;//Full height
    let percentage = (currY / totalY) * 100;//Percent value
    document.querySelector(".progress").style.width = percentage + "%";//Set progressbar width
}