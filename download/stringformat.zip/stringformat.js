String.prototype.format = function() {
    var formatted = this;
    for( var arg in arguments ) {
        formatted = formatted.replace("{" + arg + "}", arguments[arg]);
    }
    return formatted;
};
console.log("{0} + {1} = {2}".format(4, 5, 9));
console.log("{1} + {2} = {3}".format(4, 5, 9));
console.log("{0} + {0} = {1}".format(4, 5));


String.prototype.format2 = function() {
    var formatted = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{'+i+'\\}', 'gi');
        formatted = formatted.replace(regexp, arguments[i]);
    }
    return formatted;
};
console.log("{10} + {0} = {1}".format2(4, 11, 4, 8, 4, 8, 4, 8, 4, 8, 7));

let val1 = 4, val2 = 5, val3 = 13;
console.log(`${val1} + ${val2} + ${val1} = ${val3}`);
console.log('${val1} + ${val2} + ${val1} = ${val3}');


String.prototype.format3 = function() {
    var formatted = this, i = 0;
    while (/%s/.test(formatted))
        formatted = formatted.replace("%s", arguments[i++]);
    return formatted;
}
console.log("%s + %s = %s".format3(4, 5, 9));


String.format4 = function(formatted) {
    var args = Array.prototype.slice.call(arguments, 1);
    return formatted.replace(/{(\d+)}/g, function(match, number) { 
        return typeof args[number] != 'undefined' ? args[number] : match;
    });
}
console.log(String.format4("{0} + {1} = {2}", 4, 5, 9));


String.prototype.format5 = function() {
    return [...arguments].reduce((pattern,value) => pattern.replace(/%s/,value), this);
};
console.log('%s + %s = %s'.format5(4, 5, 9));