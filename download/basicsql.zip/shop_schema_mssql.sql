-- --------------------------------------------------------
-- 기초SQL 강의용 샘플 데이터베이스 생성 스크립트
-- --------------------------------------------------------

-- 데이터베이스 생성
USE master;
DROP DATABASE IF EXISTS shop;
GO
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'shop')
CREATE DATABASE shop;
GO
USE shop;
GO

-- 회원
IF NOT EXISTS(select * from sysobjects where name='member' and xtype='U')
CREATE TABLE member (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  NAME varchar(30) NOT NULL,
  PW varchar(30) NOT NULL,
  NICKNAME varchar(20),
  ZIPCODE varchar(7) DEFAULT '',
  ADDRESS varchar(255) DEFAULT '',
  MOBILE varchar(13) DEFAULT '',
  EMAIL varchar(50),
  AGE int NOT NULL DEFAULT 0,
  REGDATE datetime DEFAULT current_timestamp,
  LASTLOGIN datetime NOT NULL DEFAULT getdate(),
  DORMANT char(1) NOT NULL DEFAULT 'N'
);
GO

-- 내 포인트 누적 정보
IF NOT EXISTS(select * from sysobjects where name='mypoint' and xtype='U')
CREATE TABLE mypoint(
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID bigint FOREIGN KEY REFERENCES member(ID),
  POINT int NOT NULL default 0,
  WT timestamp
);
GO

-- 메이커
IF NOT EXISTS(select * from sysobjects where name='maker' and xtype='U')
CREATE TABLE maker (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  NAME varchar(20) NOT NULL,
  LONGNAME varchar(50) DEFAULT ''
);
GO

-- 원산지
IF NOT EXISTS(select * from sysobjects where name='madein' and xtype='U')
CREATE TABLE madein (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  COUNTRY varchar(20) NOT NULL,
  ENGNAME varchar(50) DEFAULT ''
);
GO

-- 쿠폰
IF NOT EXISTS(select * from sysobjects where name='coupon' and xtype='U')
CREATE TABLE coupon (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  TITLE varchar(255) NOT NULL,
  POINT int NOT NULL DEFAULT 0,
  STARTDATE varchar(10) DEFAULT '',
  ENDDATE varchar(10) DEFAULT ''
);
GO

-- 내쿠폰
IF NOT EXISTS(select * from sysobjects where name='mycoupon' and xtype='U')
CREATE TABLE mycoupon(
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID bigint FOREIGN KEY REFERENCES member(ID),
  couponid bigint FOREIGN KEY REFERENCES coupon(ID),
  isused char(1) NOT NULL default 'N'

);
GO

-- 상품 카테고리
IF NOT EXISTS(select * from sysobjects where name='category' and xtype='U')
CREATE TABLE category (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  TITLE varchar(50) NOT NULL
);
GO

-- 상품
IF NOT EXISTS(select * from sysobjects where name='product' and xtype='U')
CREATE TABLE product (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  NAME varchar(255) NOT NULL,
  MAKER bigint FOREIGN KEY REFERENCES maker(ID),
  IMAGE_L varchar(255) NOT NULL,
  IMAGE_B varchar(255) DEFAULT NULL,
  IMAGE_M varchar(255) DEFAULT NULL,
  IMAGE_S varchar(255) DEFAULT NULL,
  REGDATE datetime NOT NULL default getdate(),
  MADEIN char(20),
  CATEGORY bigint,
  SELL char(1) DEFAULT 'N',
  PURCHASE_PRICE int not null default 0,
  SELL_PRICE int not null default 0,
  BRAND varchar(50) DEFAULT '',
  P_OPTION varchar(30),
  DESCRIPTION text,
  LINK bigint
);
GO

-- 장바구니
IF NOT EXISTS(select * from sysobjects where name='basket' and xtype='U')
CREATE TABLE basket (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID bigint FOREIGN KEY REFERENCES member(ID),
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  P_NUM int DEFAULT 1,
  P_SELL_PRICE bigint NOT NULL DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  COUPON bigint,
  DTDMONEY int DEFAULT 0,
  WT timestamp
);
GO

-- 주문
IF NOT EXISTS(select * from sysobjects where name='p_order' and xtype='U')
CREATE TABLE p_order(
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID bigint FOREIGN KEY REFERENCES member(ID),
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  P_NUM int DEFAULT 1,
  P_SELL_PRICE bigint NOT NULL DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  COUPON bigint,
  DTDMONEY int DEFAULT 0,
  MOBILE varchar(14) not null,
  ADDRESS varchar(255),
  ZIPCODE varchar(5),
  CANCEL varchar(1) not null default 'N',
  WT datetime NOT NULL default getdate(),
);
GO

-- 찜해놓기
IF NOT EXISTS(select * from sysobjects where name='wishlist' and xtype='U')
CREATE TABLE wishlist (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID bigint FOREIGN KEY REFERENCES member(ID),
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  P_SELL_PRICE bigint DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  WT datetime NOT NULL default getdate(),
);
GO

-- 재고
IF NOT EXISTS(select * from sysobjects where name='inventory' and xtype='U')
CREATE TABLE inventory(
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  stock int NOT NULL default 0
);
GO

-- 상품 질문과 답변
IF NOT EXISTS(select * from sysobjects where name='qna' and xtype='U')
CREATE TABLE qna (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID BIGINT FOREIGN KEY REFERENCES member(ID),
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  TITLE varchar(255) NOT NULL,
  CONTENT text NOT NULL,
  WT datetime NOT NULL default getdate(),
  SECRET varchar(1) DEFAULT 'N',
  ISDELETED char(1) NOT NULL DEFAULT 'N'
);
GO

-- 구매후기
IF NOT EXISTS(select * from sysobjects where name='review' and xtype='U')
CREATE TABLE review (
  ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
  USERID BIGINT FOREIGN KEY REFERENCES member(ID),
  P_CODE bigint FOREIGN KEY REFERENCES product(ID),
  TITLE varchar(255) NOT NULL,
  CONTENT text,
  RATING int,
  WT timestamp
);
GO

-- 매출합계기록
IF NOT EXISTS(select * from sysobjects where name='stat' and xtype='U')
CREATE TABLE stat(
	ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
	USERID BIGINT FOREIGN KEY REFERENCES member(ID),
	YM varchar(7) NOT NULL,
	buysum int NOT NULL DEFAULT 0
);
GO

-- 방문자통계
IF NOT EXISTS(select * from sysobjects where name='visitor' and xtype='U')
CREATE TABLE visitor(
	ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
	USERID BIGINT,
	visit timestamp,
	ip varchar(16),
	url varchar(255)
);
GO

-- sms 발송
IF NOT EXISTS(select * from sysobjects where name='sms' and xtype='U')
CREATE TABLE sms(
	ID bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
	mobile varchar(15) not null,
	content varchar(2000) NOT NULL,
	send char(1) NOT NULL default 'N',
	WT timestamp
);
GO
