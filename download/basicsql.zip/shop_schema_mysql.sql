-- --------------------------------------------------------
-- 기초SQL 강의용 샘플 데이터베이스 생성 스크립트
-- --------------------------------------------------------

-- 데이터베이스 생성
DROP DATABASE IF EXISTS shop;
CREATE DATABASE IF NOT EXISTS shop;
USE shop;

-- 회원
CREATE TABLE IF NOT EXISTS member (
  ID bigint NOT NULL AUTO_INCREMENT,
  NAME varchar(30) NOT NULL,
  PW varchar(30) NOT NULL,
  NICKNAME varchar(20) NOT NULL,
  ZIPCODE varchar(7) DEFAULT '',
  ADDRESS varchar(255) DEFAULT '',
  MOBILE varchar(13) DEFAULT '',
  EMAIL varchar(50),
  AGE int unsigned NOT NULL DEFAULT 0,
  REGDATE datetime DEFAULT current_timestamp(),
  LASTLOGIN datetime NOT NULL DEFAULT now(),
  DORMANCY char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY ID (ID) USING BTREE
);

-- 내 포인트 누적 정보
CREATE TABLE IF NOT EXISTS mypoint(
  ID bigint NOT NULL AUTO_INCREMENT,
  USERID bigint NOT NULL,
  POINT int NOT NULL default 0,
  WT timestamp NULL DEFAULT NULL,
  PRIMARY KEY ID (ID) USING BTREE,
  FOREIGN KEY (USERID) REFERENCES member(ID)
);

-- 메이커
CREATE TABLE IF NOT EXISTS maker (
  ID bigint NOT NULL AUTO_INCREMENT,
  NAME varchar(20) NOT NULL,
  LONGNAME varchar(50) DEFAULT '',
  PRIMARY KEY (ID)
);

-- 상품
CREATE TABLE IF NOT EXISTS product (
  ID bigint NOT NULL AUTO_INCREMENT,
  NAME varchar(255) NOT NULL,
  MAKER bigint NOT NULL,
  IMAGE_L varchar(255) NOT NULL,
  IMAGE_B varchar(255) DEFAULT NULL,
  IMAGE_M varchar(255) DEFAULT NULL,
  IMAGE_S varchar(255) DEFAULT NULL,
  REGDATE timestamp,
  MADEIN char(20) NOT NULL DEFAULT '',
  CATEGORY bigint,
  SELL char(1) DEFAULT 'N',
  PURCHASE_PRICE int not null default 0,
  SELL_PRICE int not null default 0,
  BRAND varchar(50) DEFAULT '',
  P_OPTION varchar(30),
  DESCRIPTION text,
  PRIMARY KEY (ID),
  FOREIGN KEY (MAKER) REFERENCES maker(ID)
);

-- 장바구니
CREATE TABLE IF NOT EXISTS basket (
  ID bigint NOT NULL AUTO_INCREMENT,
  USERID bigint NOT NULL,
  P_CODE bigint NOT NULL,
  P_NUM int DEFAULT 1,
  P_SELL_PRICE bigint NOT NULL DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  COUPON bigint,
  DTDMONEY int DEFAULT 0,
  WT timestamp NOT NULL DEFAULT now(),
  PRIMARY KEY ID (ID),
  FOREIGN KEY (USERID) REFERENCES member(ID),
  FOREIGN KEY (P_CODE) REFERENCES product(ID)
);

-- 주문
CREATE TABLE p_order(
  ID bigint NOT NULL AUTO_INCREMENT,
  USERID bigint NOT NULL,
  P_CODE bigint NOT NULL,
  P_NUM int DEFAULT 1,
  P_SELL_PRICE bigint NOT NULL DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  COUPON bigint,
  DTDMONEY int DEFAULT 0,
  MOBILE varchar(14) not null,
  ADDRESS varchar(255) NOT NULL,
  ZIPCODE varchar(5) NOT NULL,
  CANCEL varchar(1) not null default 'N',
  WT datetime DEFAULT now(),
  PRIMARY KEY ID (ID),
  FOREIGN KEY USERID (USERID) REFERENCES member(ID),
  FOREIGN KEY P_CODE (P_CODE) REFERENCES product(ID)
);

-- 찜해놓기
CREATE TABLE IF NOT EXISTS wishlist (
  ID bigint NOT NULL AUTO_INCREMENT,
  USERID bigint NOT NULL,
  P_CODE bigint NOT NULL,
  P_SELL_PRICE bigint NOT NULL DEFAULT 0,
  P_OPTION varchar(255) DEFAULT '',
  WT timestamp NULL DEFAULT NULL,
  PRIMARY KEY ID (ID),
  FOREIGN KEY (USERID) REFERENCES member(ID),
  FOREIGN KEY (P_CODE) REFERENCES product(ID)
);

-- 재고
CREATE TABLE IF NOT EXISTS inventory(
  ID bigint NOT NULL AUTO_INCREMENT,
  P_CODE bigint NOT NULL,
  stock int unsigned NOT NULL default 0,
  PRIMARY KEY (ID),
  FOREIGN KEY (P_CODE) REFERENCES product(ID)
);

-- 원산지
CREATE TABLE IF NOT EXISTS madein (
  ID bigint NOT NULL AUTO_INCREMENT,
  COUNTRY varchar(20) NOT NULL,
  REGION varchar(50) DEFAULT '',
  PRIMARY KEY (ID)
);

-- 쿠폰
CREATE TABLE IF NOT EXISTS coupon (
  ID bigint NOT NULL AUTO_INCREMENT,
  TITLE varchar(255) NOT NULL,
  POINT int NOT NULL DEFAULT 0,
  STARTDATE varchar(10) DEFAULT '',
  ENDDATE varchar(10) DEFAULT '',
  PRIMARY KEY (ID)
);

-- 내쿠폰
CREATE TABLE IF NOT EXISTS mycoupon(
  ID bigint NOT NULL AUTO_INCREMENT,
  userid bigint NOT NULL,
  couponid bigint NOT NULL,
  PRIMARY KEY (ID),
  FOREIGN KEY (userid) REFERENCES member(ID),
  FOREIGN KEY (couponid) REFERENCES coupon(ID)
);

-- 상품 카테고리
CREATE TABLE IF NOT EXISTS category (
  ID bigint NOT NULL AUTO_INCREMENT,
  TITLE varchar(50) NOT NULL,
  PRIMARY KEY (ID)
);

-- 상품 질문과 답변
CREATE TABLE IF NOT EXISTS qna (
  ID bigint NOT NULL AUTO_INCREMENT,
  P_CODE bigint NOT NULL,
  USERID BIGINT NOT NULL,
  TITLE varchar(255) NOT NULL,
  CONTENT text NOT NULL,
  WT timestamp DEFAULT current_timestamp,
  SECRET varchar(1) DEFAULT 'N',
  PRIMARY KEY (ID),
  FOREIGN KEY (P_CODE) REFERENCES product(ID),
  FOREIGN KEY (USERID) REFERENCES member(ID)
);

-- 구매후기
CREATE TABLE IF NOT EXISTS review (
  ID bigint NOT NULL AUTO_INCREMENT,
  P_CODE bigint NOT NULL,
  USERID BIGINT NOT NULL,
  TITLE varchar(255) NOT NULL,
  CONTENT text,
  WT timestamp DEFAULT current_timestamp,
  RATING int,
  PRIMARY KEY (ID),
  FOREIGN KEY (P_CODE) REFERENCES product(ID),
  FOREIGN KEY (USERID) REFERENCES member(ID)
);

-- 매출합계기록
CREATE TABLE IF NOT EXISTS stat(
	ID bigint NOT NULL AUTO_INCREMENT,
	USERID bigint NOT NULL,
	YM varchar(7) NOT NULL,
	buysum int NOT NULL DEFAULT 0,
	PRIMARY KEY (ID),
	FOREIGN KEY (USERID) REFERENCES member(ID)  
);

-- 방문자통계
CREATE TABLE IF NOT EXISTS visitor(
	ID bigint NOT NULL AUTO_INCREMENT,
	userid bigint,
	visit timestamp,
	ip varchar(16),
	url varchar(255),
	PRIMARY KEY (ID)
);

-- sms 발송
CREATE TABLE IF NOT EXISTS sms(
	ID bigint NOT NULL AUTO_INCREMENT,
	mobile varchar(13) not null,
	content varchar(2000) NOT NULL,
	send char(1) NOT NULL default 'N',
	WT timestamp DEFAULT current_timestamp,
  PRIMARY KEY (ID)
);