use shop;

--
-- table 'category'
--
INSERT INTO category (ID, TITLE) VALUES (1,'컴퓨터용품');
INSERT INTO category (ID, TITLE) VALUES (2,'캐릭터인형');
INSERT INTO category (ID, TITLE) VALUES (3,'쿠션');
INSERT INTO category (ID, TITLE) VALUES (4,'의류');
INSERT INTO category (ID, TITLE) VALUES (5,'학용품');

--
-- table 'coupon'
--
INSERT INTO coupon (ID, TITLE, POINT, STARTDATE, ENDDATE) VALUES (1,'이달의 VIP 10% 할인 쿠폰',10, DATE '2021-04-01', DATE '2021-04-30');
INSERT INTO coupon (ID, TITLE, POINT, STARTDATE, ENDDATE) VALUES (2,'신규가입 포인트 1000점 증정',1000, DATE '2021-01-01', DATE '2021-12-31');

--
-- table 'madein'
--
INSERT INTO madein (ID, COUNTRY, ENGNAME) VALUES (1,'중국','China');
INSERT INTO madein (ID, COUNTRY, ENGNAME) VALUES (2,'대한민국','Korea');
INSERT INTO madein (ID, COUNTRY, ENGNAME) VALUES (3,'안드로메다','Andromeda');
INSERT INTO madein (COUNTRY) VALUES ('캐나다');

--
-- table 'maker'
--
INSERT INTO maker (ID, NAME, LONGNAME) VALUES (1,'카카오','카카오 중국 공장');
INSERT INTO maker (ID, NAME, LONGNAME) VALUES (2,'로지텍','로지텍 코리아');
INSERT INTO maker (ID, NAME, LONGNAME) VALUES (3,'캐릭터랜드','');

--
-- table 'member'
--
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANT) VALUES (1,'라이언','1234!@','사자아님','12345','경기도 성남시 분당구 판교동 1','010-1234-5678','ryon@kakao.com',3, TIMESTAMP '2021-03-10 00:00:00', TIMESTAMP '2021-03-10 14:59:38','N');
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANT) VALUES (2,'피치핑크','Aa1212','분홍귀신','12121','경기도 성남시 분당구 판교동 2','010-1234-5679','peachpink@kakao.com',2, TIMESTAMP '2021-03-09 00:00:00', TIMESTAMP '2021-03-09 00:00:00','N');
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANT) VALUES (3,'무야호','vmfhe','맹견','11110','경기도 성남시 분당구 판교동 3','010-1234-5680','',5, TIMESTAMP '2021-02-10 00:00:00', TIMESTAMP '2021-03-10 14:59:38','N');
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANT) VALUES (4,'티라노','가qhzhs',null,'35432','경기도 성남시 분당구 판교동 4','010-1234-5681','dinosaur@kakao.com',1, TIMESTAMP '2020-12-10 00:00:00', TIMESTAMP '2021-03-09 00:00:00','N');
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANT) VALUES (5,'무지','abcde12','안짬','12799','경기도 성남시 분당구 판교동 5','010-1234-5682','danmuji@kakao.com',3, TIMESTAMP '2021-03-31 00:00:00', TIMESTAMP '2021-03-10 14:59:38','Y');

--
-- table 'product'
--
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION, LINK) VALUES (1,'무야호 블루투스 키보드',2,'./img/large/kbd.jpg','./img/big/kbd.jpg','./img/medium/kbd.jpg','./img/small/kbd.jpg', TIMESTAMP '2021-03-10 15:00:00','1',1,'Y',12300,18500,'카카오','화이트','2021년 신상품입니다. 특가 20% 할인 판매중_',3);
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION, LINK) VALUES (2,'라이언 바디 필로우',1,'./img/large/pillow.jpg','./img/big/pillow.jpg','./img/medium/pillow.jpg','./img/small/pillow.jpg', TIMESTAMP '2021-02-28 15:00:00','2',3,'Y',27800,45000,'캐릭터랜드',NULL,'선물용으로 좋은 꿀잠을 보장하는 강추 아이템! 생일용으로도 추천!',2);
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION, LINK) VALUES (3,'피치핑크 잠옷 세트',1,'./img/large/pajama.jpg','./img/big/pajama.jpg','./img/medium/pajama.jpg','./img/small/pajama.jpg', TIMESTAMP '2020-12-14 15:00:00','1',4,'Y',42300,83000,'패플','옐로우,퍼플',NULL,NULL);
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION, LINK) VALUES (4,'무지 3색 볼펜',1,'./img/large/ballpoint3.jpg','./img/big/ballpoint3.jpg','./img/medium/ballpoint3.jpg','./img/small/ballpoint3.jpg', TIMESTAMP '2021-02-07 15:00:00','1',5,'Y',765,1400,'오피스존',NULL,'신학기 초등생을 위한 신상품 필기구 12종중 최고 인기 상품!',NULL);
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION, LINK) VALUES (5,'티라노 12색 색연필 세트',3,'./img/large/colorpen12.jpg','./img/big/colorpen12.jpg','./img/medium/colorpen12.jpg','./img/small/colorpen12.jpg', TIMESTAMP '2021-03-20 15:00:00','3',5,'N',3240,7000,'오피스존',NULL,'생일 선물로 좋은 아동 학용품 세트.',3);

--
-- table 'inventory'
--
INSERT INTO inventory (ID, P_CODE, stock) VALUES (1,1,8);
INSERT INTO inventory (ID, P_CODE, stock) VALUES (2,2,3);
INSERT INTO inventory (ID, P_CODE, stock) VALUES (3,3,15);
INSERT INTO inventory (ID, P_CODE, stock) VALUES (4,3,127);
INSERT INTO inventory (ID, P_CODE, stock) VALUES (5,5,0);

--
-- table 'basket'
--
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (1,1,1,1,18500,'화이트',NULL,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (2,4,2,2,45000,'',NULL,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (3,2,3,1,83000,'옐로우',1,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (4,2,3,1,83000,'퍼플',NULL,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (5,3,2,5,45000,'',NULL,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (6,5,5,2,7000,'',NULL,0);
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (7,2,4,10,1400,'',NULL,2500);


--
-- table 'mycoupon'
--
INSERT INTO mycoupon (ID, userid, couponid) VALUES (1,1,2);
INSERT INTO mycoupon (ID, userid, couponid) VALUES (2,2,2);
INSERT INTO mycoupon (ID, userid, couponid) VALUES (3,3,2);
INSERT INTO mycoupon (ID, userid, couponid) VALUES (4,2,1);
INSERT INTO mycoupon (ID, userid, couponid) VALUES (5,4,1);

--
-- table 'mypoint'
--
INSERT INTO mypoint (ID, USERID, POINT) VALUES (1,1,1000);
INSERT INTO mypoint (ID, USERID, POINT) VALUES (2,2,18300);
INSERT INTO mypoint (ID, USERID, POINT) VALUES (3,3,0);
INSERT INTO mypoint (ID, USERID, POINT) VALUES (4,4,1000);
INSERT INTO mypoint (ID, USERID, POINT) VALUES (5,5,8000);

--
-- table 'p_order'
--
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (1,2,3,2,83000,'옐로우',1,0,'010-1234-5679','경기도 성남시 분당구 판교동 2','12121','N', TIMESTAMP '2021-03-14 04:31:17');
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (2,4,2,1,45000,'',NULL,0,'010-1234-5682','경기도 성남시 분당구 판교동 4','35432','N', TIMESTAMP '2021-03-14 04:31:17');
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (3,5,2,1,45000,'',NULL,0,'010-1234-5683','경기도 성남시 분당구 판교동 5','12799','N', TIMESTAMP '2021-03-14 04:31:17');
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (4,1,4,3,1400,'',NULL,2500,NULL,'경기도 성남시 분당구 판교동 3','12345','N', TIMESTAMP '2021-03-14 04:31:17');
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (5,1,5,3,7000,'',NULL,25000,'010-1234-5678',NULL,'12345','Y', TIMESTAMP '2021-03-14 04:31:17');

--
-- table 'qna'
--
INSERT INTO qna (ID, P_CODE, USERID, TITLE, CONTENT, WT, SECRET) VALUES (1,5,1,'품절 문의합니다.','일주일 째 품절인데 품절이 언제 풀리는 건지 알고 싶습니다.', TIMESTAMP '2021-02-28 15:00:00','N');
INSERT INTO qna (ID, P_CODE, USERID, TITLE, CONTENT, WT, SECRET) VALUES (2,4,2,'배송 문의','오늘 주문했는데 언제 발송되는건가요?\\n금요일까지는 받을 수 있으면 좋겠습니다.', TIMESTAMP '2021-03-11 15:00:00','Y');

--
-- table 'review'
--
INSERT INTO review (ID, P_CODE, USERID, TITLE, CONTENT, RATING) VALUES (1,1,2,'대박입니다.','퀄리티 마감 모두 최고입니다. 잘 쓰겠습니다.',5);
INSERT INTO review (ID, P_CODE, USERID, TITLE, CONTENT, RATING) VALUES (2,2,3,'괜찮습니다.','약간 스크래치가 있지만, 전체적으로 만족스럽습ㄴ디ㅏ.\\n예쁘니까 모두 용서됩니다.',4);

--
-- table 'sms'
--
INSERT INTO sms (ID, mobile, content, send) VALUES (1,'010-1234-5678','주문이 완료되었습니다.','N');
INSERT INTO sms (ID, mobile, content, send) VALUES (2,'010-1234-4567','이달의 VIP 포인트가 지급되었습니다.','Y');
INSERT INTO sms (ID, mobile, content, send) VALUES (3,'010-1234-5681','주문이 완료되었습니다.','Y');
-- 페이징용 추가 데이터
insert into sms (mobile, content, wt, send) values ('010-1234-3980','안녕하세요 고객님. [바디럽_퓨어썸]상품 판매처입니다. 제주 도선료 확인이 늦어져 퓨어필터_샤워기용 배송이 늦어지는 점 죄송합니다. 확인 후 출고 진행되었습니다. 다시 한 번 불편을 드려 죄송합니다.','2021-02-19 18:42:21.693','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-6063','안녕하세요 고객님 [모도리] 상품 판매처입니다. 문의주셨던 교환접수 되었으며, 불량상품은 재포장 후 방문해주시는 회수 기사님께 전달부탁드립니다. 회수 기사님 방문까지 2~3일 소요 될 수 있음을 양해부탁드립니다.(주말제외) 감사합니다.','2021-02-19 18:00:52.007','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0201','안녕하세요. 고객님. 주문해주신 [불스원] 파워맥스 차량용 청소기 상품은 제주 도선료 추가 상품입니다. 계좌로 3,000원 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-19 12:27:55.007','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0649','안녕하세요. 고객님. 주문해주신 [JMW] 항공모터 헤어드라이기 팬텀 상품은 제주 도선료 추가 상품입니다. 계좌로 3,000원 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-19 12:27:01.383','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-10-18','안녕하세요 고객님. [에스트라] 상품 판매처입니다. 고객님의 변심 반품건 접수 되었으며 상품은 원상태 포장 후 회수 기사님께 전달부탁드립니다. 현재 택배사의 물량 증가로 인해 회수기사님 방문이 2~3일 지연될 수 있음을 양해 부탁드립니다. 감사합니다.','2021-02-19 12:20:10.803','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-8708','안녕하세요. 고객님. 주문해주신 [블랑드포레] 골드 퍼펙션 6종 세트 (캐롤프랑크 마스크 1box(4매) 증정) 상품은 제주 도선료 추가 상품입니다. 계좌로 3000원 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-19 11:40:53.137','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2239','안녕하세요. 고객님. 주문해주신 [바디럽] 상품은 도서산간료 추가 상품입니다. 계좌로 7,000원 입금해주셔야 출고준비 가능합니다. 금일까지 2시까지 입금 확인이 안될시 취소로 진행하게 되는점 양해부탁드립니다. 감사합니다. ','2021-02-19 10:14:30.987','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-6739','안녕하세요 고객님. [모도리] 상품 판매처입니다. 교환건으로 연락드렸으나 부재중이셔서 문자남깁니다. 고객님께서 불량 교환 요청해주신 내용 본사측 전달하였으나 현재 부분으로 교환은 어렵다는 답변을 받았습니다. 번거로우시겠지만 전체 상품 교환으로 진행 도와드리며 전체 상품 포장 후 회수 기사님께 전달 부탁드립니다. 고객님 상품은 익일 출고 진행 도와드리도록 하겠습니다. 불편을 드려 죄송합니다. 감사합니다. ','2021-02-18 15:37:44.923','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0578','안녕하세요 [마블_충전기] 상품 판매처입니다. 유선으로 안내드린 반품택배비는 계좌로 3,000원 입금해주셔야 반품 접수 가능합니다. 감사합니다. ','2021-02-18 15:20:10.400','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-5332','안녕하세요 고객님 [언코티드247] 상품 판매처입니다. 고객님 주문해주신 상품중 드로즈 로라이즈 네이비 색상이 품절이여 출고가 불가능해 연락드렸으나 부재중이셔서 문자 남깁니다. 다른 색상으로 대체출고 또는 취소로 진행하실 수 있습니다. 연락주시면 자세한 안내드리도록 하겠습니다. 감사합니다.','2021-02-18 15:06:56.410','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-3265','안녕하세요 고객님 [바디럽] 판매처 입니다. 반품 관련으로 연락 드렸는데 부재중이셔서 문자 드립니다. 시간 되실 때 연락 부탁드립니다.','2021-02-18 13:34:36.620','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2536','안녕하세요 고객님 경동택배 123456-110583 입니다.  불편드려 죄송합니다.  감사합니다.','2021-02-18 13:30:57.597','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-7473','안녕하세요 고객님 사진 보내주시면 감사하겠습니다.','2021-02-18 11:46:44.867','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1983','안녕하세요 고객님. [드시모네_키즈스틱] 상품 판매처입니다. 고객님께서 주문해주신 상품 품절로 출고가 어려워 연락드렸으나 부재중이셔서 문자남깁니다. 고객님 상품 취소로 안내드리며 불편을 드린점 죄송합니다. 감사합니다.','2021-02-18 11:15:38.163','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2239','안녕하세요. 고객님. 주문해주신 [바디럽] 상품은 도서산간료 추가 상품입니다. 계좌로 7,000원 입금해주셔야 출고준비 가능합니다. 감사합니다. ','2021-02-18 11:04:36.697','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-3980','안녕하세요. 고객님. 주문해주신 [바디럽][호무로] 상품은 제주도선료 추가 상품입니다. 계좌로 6,000원(2건) 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-18 11:03:16.980','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2788','안녕하세요, 고객님, 주문하신 아프리모 더바디 남/여 향수 EDP 50ml (택1) ,옵션을 저희가 설정 누락으로 인하여, 고객님 원하시는 옵션 알려주시면, 금일 출고 하도록 하겠습니다, 옵션: 남성용/ 여성용. 저희 고객센터 번호: 02-6365-7604 입니다.','2021-02-18 10:18:27.073','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2239','안녕하세요. 고객님. 주문해주신 [바디럽] 상품은 도서산간료 추가 상품입니다. 계좌로 7,000원 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-17 19:05:55.893','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1599','안녕하세요 고객님 [리프홈] 판매처입니다. 유선으로 안내드린 내용 010-4061-7601로 사진 전송해주시면 확인 후 누락상품 출고드리도록 하겠습니다. 불편을 드려 죄송합니다. 감사합니다.','2021-02-17 18:01:35.203','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-3936','안녕하세요 고객님 고객님께서 주문해주신 [호브로] 초경량 슈퍼미니 SE 마사지건 (YKG2020-01 SE)_실버가 설연휴 이후 배송 물량 증가로 배송이 지연되고 있습니다. 양해 부탁드립니다. 궁금하신 사항 있으시면 연락 주시기 바랍니다. 감사합니다. ','2021-02-17 17:55:12.237','Y');
insert into sms (mobile, content, wt, send) values ('0504-1234-4838','안녕하세요 고객님. [아프리모] 상품 판매처입니다. 고객님 상품 설연휴로 인한 택배사의 물량증가로 인해 상품 입고가 지연되어 2/18일 출고 예정입니다. 빠른 출고를 도와드리지 못하는 점 죄송합니다. 다른 사항은 02-6365-7603 으로 연락주시면 안내드리도록 하겠습니다. 감사합니다.','2021-02-17 15:38:59.863','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2184','안녕하세요 고객님. [바디럽_매트리스] 상품 판매처입니다. 고객님께서 주문해주신 상품 품절로 출고가 어려워 연락드렸으나 부재중이셔서 문자남깁니다. 고객님 상품 취소로 안내드리며 불편을 드린점 죄송합니다. 감사합니다.','2021-02-17 11:36:37.397','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-5024','안녕하세요. 고객님 저번에 저희 측 발송 실수로 고객님께 [오시스] 비접촉 체온계 회수 부탁드렸습니다. 회수가 1개 누락 되어서 연락 드립니다. 시간 괜찮으실 때 연락 부탁드립니다. 불편드려 정말 죄송합니다. 감사합니다.','2021-02-17 11:30:30.977','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1197','안녕하세요. 고객님. 주문해주신 [에스트라] 장벽 보습 피부 지킴이 아토베리아 로션 200ml 상품은 제주 도선료 추가 상품입니다. 계좌로 3000원 입금해주셔야 출고준비 가능합니다. 감사합니다.','2021-02-17 08:59:49.993','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2392','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:26:02.723','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-9545','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:25:46.733','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2006','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:25:31.987','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1297','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:24:55.263','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-4005','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:24:36.010','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0957','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:24:16.660','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1875','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:24:00.117','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1321','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:23:40.043','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-6944','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:23:24.117','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-5073','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:23:07.733','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0929','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:22:52.953','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-6569','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:22:40.920','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-0319','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:22:06.117','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-6149','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:21:44.740','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-8840','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:21:26.427','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-3988','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:21:12.127','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2676','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:20:50.673','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-1116','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:20:23.720','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-2407','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:20:10.880','Y');
insert into sms (mobile, content, wt, send) values ('010-1234-7433','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:19:54.480','Y');
insert into sms (mobile, content, wt, send) values ('0504-1234-7534','안녕하세요 고객님 고객님께서 주문하신 제품이 설 연휴 기간 택배 물량 증가로 순차적으로 출고될 예정입니다. 양해 부탁 드립니다. 감사합니다.','2021-02-16 18:19:12.183','Y');
--
-- table 'stat'
--
INSERT INTO stat (ID, YM, userid, buysum) VALUES (1, to_date('2021-03','YYYY-MM'),1,385000);
INSERT INTO stat (ID, YM, userid, buysum) VALUES (2, to_date('2021-03','YYYY-MM'),2,15400);
INSERT INTO stat (ID, YM, userid, buysum) VALUES (3, to_date('2021-03','YYYY-MM'),3,64200);
INSERT INTO stat (ID, YM, userid, buysum) VALUES (4, to_date('2021-03','YYYY-MM'),4,0);
INSERT INTO stat (ID, YM, userid, buysum) VALUES (5, to_date('2021-03','YYYY-MM'),5,127400);

--
-- table 'wishlist'
--
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (1,2,1,18500,'화이트', TIMESTAMP '2021-03-11 11:24:21');
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (2,3,2,45000,'', TIMESTAMP '2021-03-09 20:03:34');
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (4,1,3,83000,'퍼플', TIMESTAMP '2021-03-13 18:33:45');
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (5,2,2,45000,'', TIMESTAMP '2021-03-03 12:40:01');
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (6,5,5,7000,'', TIMESTAMP '2021-02-24 19:31:55');
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (7,5,4,NULL,'', TIMESTAMP '2021-02-28 23:48:10');

COMMIT;