use shop;

--
-- table `category`
--
LOCK TABLES `category` WRITE;
INSERT INTO `category` (`ID`, `TITLE`) VALUES (1,'컴퓨터용품'),(2,'캐릭터인형'),(3,'쿠션'),(4,'의류'),(5,'학용품');
UNLOCK TABLES;

--
-- table `coupon`
--
LOCK TABLES `coupon` WRITE;
INSERT INTO `coupon` (`ID`, `TITLE`, `POINT`, `STARTDATE`, `ENDDATE`) VALUES (1,'이달의 VIP 10% 할인 쿠폰',10,'2021-04-01','2021-04-30'),(2,'신규가입 포인트 1000점 증정',1000,'2021-01-01','2021-12-31');
UNLOCK TABLES;

--
-- table `madein`
--
LOCK TABLES `madein` WRITE;
INSERT INTO `madein` (`ID`, `COUNTRY`, `REGION`) VALUES (1,'중국',''),(2,'대한민국',''),(3,'안드로메다','');
UNLOCK TABLES;

--
-- table `maker`
--
LOCK TABLES `maker` WRITE;
INSERT INTO `maker` (`ID`, `NAME`, `LONGNAME`) VALUES (1,'카카오','카카오 중국 공장'),(2,'로지텍','로지텍 코리아'),(3,'캐릭터랜드','');
UNLOCK TABLES;

--
-- table `member`
--
LOCK TABLES `member` WRITE;
INSERT INTO `member` (`ID`, `NAME`, `PW`, `NICKNAME`, `ZIPCODE`, `ADDRESS`, `MOBILE`, `EMAIL`, `AGE`, `REGDATE`, `LASTLOGIN`, `DORMANCY`) VALUES (1,'라이언','1234!@','사자아님','12345','경기도 성남시 분당구 판교동 1','010-1234-5678','ryon@kakao.com',3,'2021-03-10 00:00:00','2021-03-10 14:59:38','N'),(2,'피치핑크','aa1212','분홍귀신','12121','경기도 성남시 분당구 판교동 2','010-1234-5679','peachpink@kakao.com',2,'2021-03-09 00:00:00','2021-03-09 00:00:00','N'),(3,'무야호','vmfheh','맹견','11110','경기도 성남시 분당구 판교동 3','010-1234-5680','muyaho@kakao.com',5,'2021-02-10 00:00:00','2021-03-10 14:59:38','N'),(4,'티라노','qkqhzhs','곤룡','35432','경기도 성남시 분당구 판교동 4','010-1234-5681','dinosaur@kakao.com',1,'2020-12-10 00:00:00','2021-03-09 00:00:00','N'),(5,'무지','abcde12','안짬','12799','경기도 성남시 분당구 판교동 5','010-1234-5682','danmuji@kakao.com',3,'2021-03-31 00:00:00','2021-03-10 14:59:38','Y');
UNLOCK TABLES;

--
-- table `product`
--
LOCK TABLES `product` WRITE;
INSERT INTO `product` (`ID`, `NAME`, `MAKER`, `IMAGE_L`, `IMAGE_B`, `IMAGE_M`, `IMAGE_S`, `REGDATE`, `MADEIN`, `CATEGORY`, `SELL`, `PURCHASE_PRICE`, `SELL_PRICE`, `BRAND`, `P_OPTION`, `DESCRIPTION`) VALUES (1,'무야호 블루투스 키보드',2,'./img/large/kbd.jpg','./img/big/kbd.jpg','./img/medium/kbd.jpg','./img/small/kbd.jpg','2021-03-10 15:00:00','1',1,'Y',12300,18500,'카카오','화이트',NULL),(2,'라이언 바디 필로우',1,'./img/large/pillow.jpg','./img/big/pillow.jpg','./img/medium/pillow.jpg','./img/small/pillow.jpg','2021-02-28 15:00:00','2',3,'Y',27800,45000,'캐릭터랜드',NULL,NULL),(3,'피치핑크 잠옷 세트',1,'./img/large/pajama.jpg','./img/big/pajama.jpg','./img/medium/pajama.jpg','./img/small/pajama.jpg','2020-12-14 15:00:00','1',4,'Y',42300,83000,'패플','옐로우,퍼플',NULL),(4,'무지 3색 볼펜',1,'./img/large/ballpoint3.jpg','./img/big/ballpoint3.jpg','./img/medium/ballpoint3.jpg','./img/small/ballpoint3.jpg','2021-02-07 15:00:00','1',5,'Y',765,1400,'오피스존',NULL,NULL),(5,'티라노 12색 색연필 세트',3,'./img/large/colorpen12.jpg','./img/big/colorpen12.jpg','./img/medium/colorpen12.jpg','./img/small/colorpen12.jpg','2021-03-20 15:00:00','3',5,'N',3240,7000,'오피스존',NULL,NULL);
UNLOCK TABLES;

--
-- table `inventory`
--
LOCK TABLES `inventory` WRITE;
INSERT INTO `inventory` (`ID`, `P_CODE`, `stock`) VALUES (2,1,8),(3,2,3),(4,3,15),(5,4,127),(6,5,0);
UNLOCK TABLES;

--
-- table `basket`
--
LOCK TABLES `basket` WRITE;
INSERT INTO `basket` (`ID`, `USERID`, `P_CODE`, `P_NUM`, `P_SELL_PRICE`, `P_OPTION`, `COUPON`, `DTDMONEY`, `WT`) VALUES (1,1,1,1,18500,'화이트',NULL,0,'2021-03-11 11:24:21'),(2,4,2,2,45000,'',NULL,0,'2021-03-09 20:03:34'),(3,2,3,1,83000,'옐로우',1,0,'2021-02-28 23:48:10'),(4,2,3,1,83000,'퍼플',NULL,0,'2021-02-24 19:31:55'),(5,3,2,5,45000,'',NULL,0,'2021-03-03 12:40:01'),(6,5,5,2,7000,'',NULL,0,'2021-03-13 18:33:45'),(7,2,4,10,1400,'',NULL,2500,'2021-03-06 05:21:10');
UNLOCK TABLES;

--
-- table `mycoupon`
--
LOCK TABLES `mycoupon` WRITE;
INSERT INTO `mycoupon` (`ID`, `userid`, `couponid`) VALUES (1,1,2),(2,2,2),(3,3,2),(4,2,1),(5,4,1);
UNLOCK TABLES;

--
-- table `mypoint`
--
LOCK TABLES `mypoint` WRITE;
INSERT INTO `mypoint` (`ID`, `USERID`, `POINT`, `WT`) VALUES (1,1,1000,'2021-03-19 10:15:21'),(2,2,18300,'2021-02-27 03:18:33'),(3,3,0,'2021-03-04 12:50:11'),(4,4,1000,'2021-03-07 04:31:20'),(5,5,8000,'2021-02-26 14:31:55');
UNLOCK TABLES;

--
-- table `p_order`
--
LOCK TABLES `p_order` WRITE;
INSERT INTO `p_order` (`ID`, `USERID`, `P_CODE`, `P_NUM`, `P_SELL_PRICE`, `P_OPTION`, `COUPON`, `DTDMONEY`, `MOBILE`, `ADDRESS`, `ZIPCODE`, `CANCEL`, `WT`) VALUES (1,2,3,2,83000,'옐로우',1,0,'010-1234-5679','경기도 성남시 분당구 판교동 2','12121','N','2021-03-14 04:31:17'),(2,4,2,1,45000,'',NULL,0,'010-1234-5682','경기도 성남시 분당구 판교동 4','35432','N','2021-03-14 04:31:17'),(3,5,2,1,45000,'',NULL,0,'010-1234-5683','경기도 성남시 분당구 판교동 5','12799','N','2021-03-14 04:31:17'),(4,1,4,3,1400,'',NULL,2500,'010-1234-5678','경기도 성남시 분당구 판교동 1','12345','N','2021-03-14 04:31:17'),(5,1,5,3,7000,'',NULL,25000,'010-1234-5678','경기도 성남시 분당구 판교동 1','12345','Y','2021-03-14 04:31:17');
UNLOCK TABLES;

--
-- table `qna`
--
LOCK TABLES `qna` WRITE;
INSERT INTO `qna` (`ID`, `P_CODE`, `USERID`, `TITLE`, `CONTENT`, `WT`, `SECRET`) VALUES (1,5,1,'품절 문의합니다.','일주일 째 품절인데 품절이 언제 풀리는 건지 알고 싶습니다.','2021-02-28 15:00:00','N'),(2,4,2,'배송 문의','오늘 주문했는데 언제 발송되는건가요?\\n금요일까지는 받을 수 있으면 좋겠습니다.','2021-03-11 15:00:00','Y');
UNLOCK TABLES;

--
-- table `review`
--
LOCK TABLES `review` WRITE;
INSERT INTO `review` (`ID`, `P_CODE`, `USERID`, `TITLE`, `CONTENT`, `WT`, `RATING`) VALUES (1,1,2,'대박입니다.','퀄리티 마감 모두 최고입니다. 잘 쓰겠습니다.','2021-03-14 15:00:00',5),(2,2,3,'괜찮습니다.','약간 스크래치가 있지만, 전체적으로 만족스럽습ㄴ디ㅏ.\\n예쁘니까 모두 용서됩니다.','2021-02-25 15:00:00',4);
UNLOCK TABLES;

--
-- table `sms`
--
LOCK TABLES `sms` WRITE;
INSERT INTO `sms` (`ID`, `mobile`, `content`, `send`, `WT`) VALUES (1,'010-1234-5678','주문이 완료되었습니다.','N','2021-03-13 15:00:00'),(2,'010-1234-4567','이달의 VIP 포인트가 지급되었습니다.','Y','2021-03-14 15:00:00'),(3,'010-1234-5681','주문이 완료되었습니다.','Y','2021-03-14 16:13:25');
UNLOCK TABLES;

--
-- table `stat`
--
LOCK TABLES `stat` WRITE;
INSERT INTO `stat` (`ID`, `YM`, `userid`, `buysum`) VALUES (1,'2021-03',1,385000),(2,'2021-03',2,15400),(3,'2021-03',3,64200),(4,'2021-03',4,0),(5,'2021-03',5,127400);
UNLOCK TABLES;

--
-- table `wishlist`
--
LOCK TABLES `wishlist` WRITE;
INSERT INTO `wishlist` (`ID`, `USERID`, `P_CODE`, `P_SELL_PRICE`, `P_OPTION`, `WT`) VALUES (1,2,1,18500,'화이트','2021-03-11 11:24:21'),(2,3,2,45000,'','2021-03-09 20:03:34'),(3,4,3,83000,'옐로우','2021-03-06 05:21:10'),(4,1,3,83000,'퍼플','2021-03-13 18:33:45'),(5,2,2,45000,'','2021-03-03 12:40:01'),(6,5,5,7000,'','2021-02-24 19:31:55'),(7,5,4,1400,'','2021-02-28 23:48:10');
UNLOCK TABLES;