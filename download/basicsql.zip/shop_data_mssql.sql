use shop;

--
-- table 'category'
--
SET IDENTITY_INSERT dbo.category ON;
INSERT INTO category (ID, TITLE) VALUES (1,'컴퓨터용품'),(2,'캐릭터인형'),(3,'쿠션'),(4,'의류'),(5,'학용품');
SET IDENTITY_INSERT dbo.category OFF;
GO

--
-- table 'coupon'
--
SET IDENTITY_INSERT dbo.coupon ON;
INSERT INTO coupon (ID, TITLE, POINT, STARTDATE, ENDDATE) VALUES (1,'이달의 VIP 10% 할인 쿠폰',10,'2021-04-01','2021-04-30'),(2,'신규가입 포인트 1000점 증정',1000,'2021-01-01','2021-12-31');
SET IDENTITY_INSERT dbo.coupon OFF;
GO

--
-- table 'madein'
--
SET IDENTITY_INSERT dbo.madein ON;
INSERT INTO madein (ID, COUNTRY, REGION) VALUES (1,'중국',''),(2,'대한민국',''),(3,'안드로메다','');
SET IDENTITY_INSERT dbo.madein OFF;
GO

--
-- table 'maker'
--
SET IDENTITY_INSERT dbo.maker ON;
INSERT INTO maker (ID, NAME, LONGNAME) VALUES (1,'카카오','카카오 중국 공장'),(2,'로지텍','로지텍 코리아'),(3,'캐릭터랜드','');
SET IDENTITY_INSERT dbo.maker OFF;
GO

--
-- table 'member'
--
SET IDENTITY_INSERT dbo.member ON;
INSERT INTO member (ID, NAME, PW, NICKNAME, ZIPCODE, ADDRESS, MOBILE, EMAIL, AGE, REGDATE, LASTLOGIN, DORMANCY) VALUES (1,'라이언','1234!@','사자아님','12345','경기도 성남시 분당구 판교동 1','010-1234-5678','ryon@kakao.com',3,'2021-03-10 00:00:00','2021-03-10 14:59:38','N'),(2,'피치핑크','aa1212','분홍귀신','12121','경기도 성남시 분당구 판교동 2','010-1234-5679','peachpink@kakao.com',2,'2021-03-09 00:00:00','2021-03-09 00:00:00','N'),(3,'무야호','vmfheh','맹견','11110','경기도 성남시 분당구 판교동 3','010-1234-5680','muyaho@kakao.com',5,'2021-02-10 00:00:00','2021-03-10 14:59:38','N'),(4,'티라노','qkqhzhs','곤룡','35432','경기도 성남시 분당구 판교동 4','010-1234-5681','dinosaur@kakao.com',1,'2020-12-10 00:00:00','2021-03-09 00:00:00','N'),(5,'무지','abcde12','안짬','12799','경기도 성남시 분당구 판교동 5','010-1234-5682','danmuji@kakao.com',3,'2021-03-31 00:00:00','2021-03-10 14:59:38','Y');
SET IDENTITY_INSERT dbo.member OFF;
GO

--
-- table 'product'
--
SET IDENTITY_INSERT dbo.product ON;
INSERT INTO product (ID, NAME, MAKER, IMAGE_L, IMAGE_B, IMAGE_M, IMAGE_S, REGDATE, MADEIN, CATEGORY, SELL, PURCHASE_PRICE, SELL_PRICE, BRAND, P_OPTION, DESCRIPTION) VALUES (1,'무야호 블루투스 키보드',2,'./img/large/kbd.jpg','./img/big/kbd.jpg','./img/medium/kbd.jpg','./img/small/kbd.jpg','2021-03-10 15:00:00','1',1,'Y',12300,18500,'카카오','화이트',NULL),(2,'라이언 바디 필로우',1,'./img/large/pillow.jpg','./img/big/pillow.jpg','./img/medium/pillow.jpg','./img/small/pillow.jpg','2021-02-28 15:00:00','2',3,'Y',27800,45000,'캐릭터랜드',NULL,NULL),(3,'피치핑크 잠옷 세트',1,'./img/large/pajama.jpg','./img/big/pajama.jpg','./img/medium/pajama.jpg','./img/small/pajama.jpg','2020-12-14 15:00:00','1',4,'Y',42300,83000,'패플','옐로우,퍼플',NULL),(4,'무지 3색 볼펜',1,'./img/large/ballpoint3.jpg','./img/big/ballpoint3.jpg','./img/medium/ballpoint3.jpg','./img/small/ballpoint3.jpg','2021-02-07 15:00:00','1',5,'Y',765,1400,'오피스존',NULL,NULL),(5,'티라노 12색 색연필 세트',3,'./img/large/colorpen12.jpg','./img/big/colorpen12.jpg','./img/medium/colorpen12.jpg','./img/small/colorpen12.jpg','2021-03-20 15:00:00','3',5,'N',3240,7000,'오피스존',NULL,NULL);
SET IDENTITY_INSERT dbo.product OFF;
GO

--
-- table 'inventory'
--
SET IDENTITY_INSERT dbo.inventory ON;
INSERT INTO inventory (ID, P_CODE, stock) VALUES (2,1,8),(3,2,3),(4,3,15),(5,4,127),(6,5,0);
SET IDENTITY_INSERT dbo.inventory OFF;
GO

--
-- table 'basket'
--
SET IDENTITY_INSERT dbo.basket ON;
INSERT INTO basket (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY) VALUES (1,1,1,1,18500,'화이트',NULL,0),(2,4,2,2,45000,'',NULL,0),(3,2,3,1,83000,'옐로우',1,0),(4,2,3,1,83000,'퍼플',NULL,0),(5,3,2,5,45000,'',NULL,0),(6,5,5,2,7000,'',NULL,0),(7,2,4,10,1400,'',NULL,2500);
SET IDENTITY_INSERT dbo.basket OFF;
GO

--
-- table 'mycoupon'
--
SET IDENTITY_INSERT dbo.mycoupon ON;
INSERT INTO mycoupon (ID, userid, couponid) VALUES (1,1,2),(2,2,2),(3,3,2),(4,2,1),(5,4,1);
SET IDENTITY_INSERT dbo.mycoupon OFF;
GO

--
-- table 'mypoint'
--
SET IDENTITY_INSERT dbo.mypoint ON;
INSERT INTO mypoint (ID, USERID, POINT) VALUES (1,1,1000),(2,2,18300),(3,3,0),(4,4,1000),(5,5,8000);
SET IDENTITY_INSERT dbo.mypoint OFF;
GO

--
-- table 'p_order'
--
SET IDENTITY_INSERT dbo.p_order ON;
INSERT INTO p_order (ID, USERID, P_CODE, P_NUM, P_SELL_PRICE, P_OPTION, COUPON, DTDMONEY, MOBILE, ADDRESS, ZIPCODE, CANCEL, WT) VALUES (1,2,3,2,83000,'옐로우',1,0,'010-1234-5679','경기도 성남시 분당구 판교동 2','12121','N','2021-03-14 04:31:17'),(2,4,2,1,45000,'',NULL,0,'010-1234-5682','경기도 성남시 분당구 판교동 4','35432','N','2021-03-14 04:31:17'),(3,5,2,1,45000,'',NULL,0,'010-1234-5683','경기도 성남시 분당구 판교동 5','12799','N','2021-03-14 04:31:17'),(4,1,4,3,1400,'',NULL,2500,'010-1234-5678','경기도 성남시 분당구 판교동 1','12345','N','2021-03-14 04:31:17'),(5,1,5,3,7000,'',NULL,25000,'010-1234-5678','경기도 성남시 분당구 판교동 1','12345','Y','2021-03-14 04:31:17');
SET IDENTITY_INSERT dbo.p_order OFF;
GO

--
-- table 'qna'
--
SET IDENTITY_INSERT dbo.qna ON;
INSERT INTO qna (ID, P_CODE, USERID, TITLE, CONTENT, WT, SECRET) VALUES (1,5,1,'품절 문의합니다.','일주일 째 품절인데 품절이 언제 풀리는 건지 알고 싶습니다.','2021-02-28 15:00:00','N'),(2,4,2,'배송 문의','오늘 주문했는데 언제 발송되는건가요?\\n금요일까지는 받을 수 있으면 좋겠습니다.','2021-03-11 15:00:00','Y');
SET IDENTITY_INSERT dbo.qna OFF;
GO

--
-- table 'review'
--
SET IDENTITY_INSERT dbo.review ON;
INSERT INTO review (ID, P_CODE, USERID, TITLE, CONTENT, RATING) VALUES (1,1,2,'대박입니다.','퀄리티 마감 모두 최고입니다. 잘 쓰겠습니다.',5),(2,2,3,'괜찮습니다.','약간 스크래치가 있지만, 전체적으로 만족스럽습ㄴ디ㅏ.\\n예쁘니까 모두 용서됩니다.',4);
SET IDENTITY_INSERT dbo.review OFF;
GO

--
-- table 'sms'
--
SET IDENTITY_INSERT dbo.sms ON;
INSERT INTO sms (ID, mobile, content, send) VALUES (1,'010-1234-5678','주문이 완료되었습니다.','N'),(2,'010-1234-4567','이달의 VIP 포인트가 지급되었습니다.','Y'),(3,'010-1234-5681','주문이 완료되었습니다.','Y');
SET IDENTITY_INSERT dbo.sms OFF;
GO

--
-- table 'stat'
--
SET IDENTITY_INSERT dbo.stat ON;
INSERT INTO stat (ID, YM, userid, buysum) VALUES (1,'2021-03',1,385000),(2,'2021-03',2,15400),(3,'2021-03',3,64200),(4,'2021-03',4,0),(5,'2021-03',5,127400);
SET IDENTITY_INSERT dbo.stat OFF;
GO

--
-- table 'wishlist'
--
SET IDENTITY_INSERT dbo.wishlist ON;
INSERT INTO wishlist (ID, USERID, P_CODE, P_SELL_PRICE, P_OPTION, WT) VALUES (1,2,1,18500,'화이트','2021-03-11 11:24:21'),(2,3,2,45000,'','2021-03-09 20:03:34'),(3,4,3,83000,'옐로우','2021-03-06 05:21:10'),(4,1,3,83000,'퍼플','2021-03-13 18:33:45'),(5,2,2,45000,'','2021-03-03 12:40:01'),(6,5,5,7000,'','2021-02-24 19:31:55'),(7,5,4,1400,'','2021-02-28 23:48:10');
SET IDENTITY_INSERT dbo.wishlist OFF;
GO
