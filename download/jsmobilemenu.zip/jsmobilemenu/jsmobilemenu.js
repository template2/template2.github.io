document.addEventListener('DOMContentLoaded', function(){
    document.querySelector(".mobile-menu").addEventListener("click", function(e){
        if ( document.querySelector('.menuwrap').classList.contains('on') ){
            //Close menu
            document.querySelector('.menuwrap').classList.remove('on');
            document.querySelector('.mobile-menu i').classList.remove('fa-times')
            document.querySelector('.mobile-menu i').classList.add('fa-bars');

            //Release page scroll lock
            document.querySelector('#dimmed').remove();
        } else {
            //Open menu
            document.querySelector('.menuwrap').classList.add('on');
            document.querySelector('.mobile-menu i').classList.remove('fa-bars');
            document.querySelector('.mobile-menu i').classList.add('fa-times');

            //Append page scroll lock layer
            let div = document.createElement('div');
            div.id = 'dimmed';
            document.body.append(div);

            //Block page scroll lock mobile event
            document.querySelector('#dimmed').addEventListener('scroll touchmove touchend mousewheel', function(e){
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            //Close the menu when you click the page scroll lock layer
            document.querySelector('#dimmed').addEventListener('click', function(e){
                document.querySelector(".mobile-menu").click();
            });             
        }
    });
});