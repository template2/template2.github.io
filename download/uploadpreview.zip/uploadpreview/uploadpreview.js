document.addEventListener('DOMContentLoaded', function(){
    // Image extension validation with image object type
    var validateType = function(img){
        return (['image/jpeg','image/jpg','image/png'].indexOf(img.type) > -1);
    }

	//File extension validator
	var validateType = function(fname){
		let extensions = ['jpeg','jpg','png'];
		let fparts = fname.split('.');
		let fext = '';

		if(fparts.length > 1){
			fext = fparts[fparts.length-1];
		}

		let validated = false;

		if(fext != ''){
			extensions.forEach(function(ext){
				if(ext == fext){
					validated = true;
				}
			});
		}
		return validated;
	}

    // Register an event listener in the file selection field
	document.getElementById('imageSelector').addEventListener('change', function(e){
		let elem = e.target;
		if(validateType(elem.files[0])){
			let preview = document.querySelector('.thumb');
			preview.src = URL.createObjectURL(elem.files[0]); // Get image data from file object.
			document.querySelector('.dellink').style.display = 'block'; // Show delete image link
			preview.onload = function() {
				URL.revokeObjectURL(preview.src); // Release URL Object
			}
		}else{
			console.log('Not an image file.');
		}
	});

	document.querySelector('.dellink').addEventListener('click', function(e){
		document.querySelector('.thumb').src = ''; // Thumbnail image src data release
		document.querySelector('.dellink').style.display = 'none';
	});
});
