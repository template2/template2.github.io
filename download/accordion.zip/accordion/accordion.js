window.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('details').forEach(function(item){
      item.addEventListener("toggle", event => {
      let toggled = event.target;
      if (toggled.attributes.open) {/* If open and item */
        /* Close other opend items */
        document.querySelectorAll('details[open]').forEach(function(opened){
            if(toggled != opened) /* If the element is not currently opened */
              opened.removeAttribute('open'); /* Delete "open" attribute */
        });
      }
    })
  });
});