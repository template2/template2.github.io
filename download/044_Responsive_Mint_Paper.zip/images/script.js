(function($) {

	
	var $is_mobile = false;//모바일 기기 체크
	checkMobile()

	var bSidebarCategory = $('body.categoryside').length ? true:false;//카테고리 방향 결정

	setMobileCategory(); //모바일 메뉴로 카테고리 붙였다 뗌
	setNoImage();

	function gnb(){
		$("#header").on("click", ".mobile-menu", function(){
			if ( $(this).hasClass("on") ){
				//모바일 사이드 메뉴 온시 컨텐츠 스크롤 락
				//$('body').css('overflow','visible');
				$('#dimmed').off('scroll touchmove touchend mousewheel');
				$(this).removeClass("on");
				$("#header .menu").removeClass("on");
				$("#dimmed").remove();
			} else {
				$(this).addClass("on");
				$("#header .menu").addClass("on");
				$("body").append('<div id="dimmed" />').on("click", "#dimmed", function(){
					$(".mobile-menu").click();
				});

				//모바일 사이드 메뉴 온시 컨텐츠 스크롤 락 해제
				//$('body').css('overflow','hidden');
				$('#dimmed').on('scroll touchmove touchend mousewheel', function(e){
					e.preventDefault();
					e.stopPropagation();
					return false;
				});				
			}
		});

		$(window).scroll(function(){
			var height = $(window).scrollTop();
			if ( $('.btn-top').length ){
				if(height > 0){
					$('.btn-top').removeClass('hideanim');
				}else{
					$('.btn-top').addClass('hideanim');
				}
			}
		});

		$(document).on("click", "#header .search", function(){
			if ( !$(this).hasClass("on") ){
				$(this).addClass("on").find("input").focus();
				return false;
			}
		});
		$(document).on("click", ".close-search", function(){
				$("#header .search").removeClass("on").find("input").focus();
				return false;
		});
	}

	function coverSlider(){
		$(".cover-slider").each(function(){
			
			var $this = $(this); // 현재 슬라이드 이너 객체

			//환경설정
			$interval = 5000; // 슬라이드 이동 간격 - 기본설정 5000(5초), 0이면 멈춤, 슬라이드 교체 간격
			$animateTime = 500; // 슬라이드 이동시간 - 기본설정 500(0.5초), 커지면 느리게 애니메이션
			// 슬라이드 애니메이션 타입
			$animtype = 0; // 0:오른쪽방향 이동(next클릭), 1: 왼쪽방향 이동(prev클릭), 2: 페이드인아웃 오른쪽 방향(next클릭), 3: 페이드인아웃 왼쪽 방향(prev클릭)

			//애니메이션 내부처리용 변수
			$sliderItems = $(this).find("li"), // 슬라이드 아이템들 객체 리스트
			$itemsLength = $sliderItems.length, // 슬라이드 아이템 갯수
			$num = 0, // 슬라이드 인덱스
			$looper = null; // 슬라이드 인터벌 타이머 객체
			$timeouts = [];
			//애니메이션 타입별 트랜지션 기본값 설정
			$animstart = {left: "100%"};
			$animtrans = {left: "0"};
			$animend = {left: "-100%"};
			$animdirectcss = ".next";
			$slideview = 'table'; //페이드 처리용 인액티브 슬라이드 순서
			$transslideview = 'table'; //페이드 처리용 액티브 슬라이드 순서

			// 디폴트 0 제외하고 나머지 애니메이션 타입만 설정
			switch($animtype){
				case 1:
					$animdirectcss = ".prev";
					break;
				case 2:
					$animstart = {opacity: 0};
					$animtrans = {opacity: 1};
					$animend = {opacity: 0};
					$slideview = 'none';
					break;
				case 3:
					$animstart = {opacity: 0};
					$animtrans = {opacity: 1};
					$animend = {opacity: 0};
					$slideview = 'none';
					$animdirectcss = ".prev";
					break;
			}
			
			if ( $itemsLength > 1 ){
				//add prev, next button
				$this.append('<button type="button" class="prev"><span>이전</span></button><button type="button" class="next"><span>다음</span></button>');
					
				//add indicator
				$this.append('<ol class="cover-slider-indicator"></ol>');

				$looper = setLoop();//자동 루프

				for(let i=0;i<$itemsLength;i++){
					var $element = $('<li index="'+i+'" class="'+(i==0?'active':'')+'"></li>');
					$element.click(function(){
						
						var $clicked_indicator = parseInt($(this).attr('index'));
						if($num != $clicked_indicator){
							var sliding_size = Math.abs($num - $clicked_indicator);
							clearInterval($looper);//임시로 루프 죽이고
							
							for(let j = 0;j<sliding_size;j++){
								(function(direction, index){
									$timeouts.push(setTimeout(function(){
										moveCascadeSlides(direction, index);
										},$animateTime*index));
									}
								)(($num < $clicked_indicator ? 1:-1), j);
							}
							$looper = setLoop();//루프 재설정
						}
					});
					$this.find('.cover-slider-indicator').append($element);
				}
				//add css property to slider
				$sliderItems.css({
					"position": "absolute",
					"top": 0,
				});
				$sliderItems.eq($num).css(Object.keys($animtrans)[0], $animtrans[Object.keys($animtrans)[0]]).css('display', $transslideview);
				$sliderItems.eq($num).siblings().css(Object.keys($animstart)[0], $animstart[Object.keys($animstart)[0]]).css('display', $slideview);
	
				//add prev click event
				$this.on("click", ".prev", function(){
					if ( !$sliderItems.eq($num).is(":animated") ){
						clearInterval($looper);//임시로 루프 죽이고
						var $pnum=$num;
						$sliderItems.eq($num).animate($animstart, $animateTime, function(){slideDisplay($pnum, $slideview);});
						$sliderItems.eq($num).siblings().css(Object.keys($animend)[0], $animend[Object.keys($animend)[0]]);
						$num = $num-1 < 0 ? $sliderItems.length-1 : $num-1;
						moveSlide($num);
						$($this).find('ol li').removeClass('active');
						$($this).find('ol li').eq($num).addClass('active');
						$looper = setLoop();//루프 재설정
					}
				});
				
				//add next click event
				$this.on("click", ".next", function(){
					if ( !$sliderItems.eq($num).is(":animated") ){
						clearInterval($looper);//임시로 루프 죽이고
						var $pnum=$num;
						$sliderItems.eq($num).animate($animend, $animateTime, function(){slideDisplay($pnum, $slideview);});
						$sliderItems.eq($num).siblings().css(Object.keys($animstart)[0], $animstart[Object.keys($animstart)[0]]);
						$num = $num+1 >= $sliderItems.length ? 0 : $num+1;
						moveSlide($num);
						$($this).find('ol li').removeClass('active');
						$($this).find('ol li').eq($num).addClass('active');
						$looper = setLoop();//루프 재설정
					}
				});
				
				//slide rotate init
				function setLoop(){
					if($interval > 0){
						return setInterval(
							function autoScrollSlider(){
								$($this).find($animdirectcss).trigger( "click" );
							}, $interval
						);
					}
				}
	
				//animate indicator click
				function moveCascadeSlides(direction, idx){
					var $next_num = $num + direction;
					var $pnum = $num;
					$sliderItems.eq($num).animate(direction==1?$animend:$animstart, $animateTime, function(){slideDisplay($pnum, $slideview);});
					$sliderItems.eq($num).siblings().css(Object.keys($animstart)[0], direction==1?$animstart[Object.keys($animstart)[0]]:$animend[Object.keys($animend)[0]]);
					$sliderItems.eq($next_num).css('display', $transslideview).animate($animtrans, $animateTime);
					$($this).find('ol li').removeClass('active');
					$($this).find('ol li').eq($next_num).addClass('active');
					$num = $next_num;
					clearTimeout($timeouts[idx]);
				}
				
				//animate 1 slide item
				function moveSlide(newnum){
					$sliderItems.eq(newnum).css('display', $transslideview).animate($animtrans, $animateTime);
					$(".cover-slider .paging button").eq(newnum).addClass("current").siblings().removeClass("current");
				}

				//z-index change callback function
				function slideDisplay(idx, state_display){
					$sliderItems.eq(idx).css('display',state_display);
				}
	
				//add mobile touch
				$this.on("touchstart", function(){
					var touch = event.touches[0];
					touchstartX = touch.clientX,
					touchstartY = touch.clientY;
				});
	
				//add mobile touch end
				$this.on("touchend", function(){
					if( event.touches.length == 0 ){
						var touch = event.changedTouches[event.changedTouches.length - 1];
						touchendX = touch.clientX,
						touchendY = touch.clientY,
						touchoffsetX = touchendX - touchstartX,
						touchoffsetY = touchendY - touchstartY;
	
						if ( Math.abs(touchoffsetX) > 10 && Math.abs(touchoffsetY) <= 100 ){
							if (touchoffsetX < 0 ){
								$this.find(".next").click();
							} else {
								$this.find(".prev").click();
							}
						}
					}
				});
				
				//set slider item index text
				//각 슬라이더 텍스트에 1/3, 2/3, 3/3 과 같이 인덱스를 붙이고 싶은 경우 .index 클래스로 커버 슬라이더 <li> 태그 안에 <span class="index"></span> 식으로 태그를 넣어주면 자동으로 인덱스가 붙음
				/*
				$this.find('.index').each(function(idx){
					$(this).html((idx+1)+'/'+$itemsLength)
				})
				*/
				
				//set cover slider height
				//커버 슬라이더(.cover-slider)에 높이 값이 정의되지 않거나 내부 슬라이더 이미지 크기에 맞춰 자동으로 높이를 맞출 필요가 있을 경우 아래 행이 그 기능을 함.
				//csds에 .cover-slider 높이값이 강제 적용하는 경우 아래행을 리마크 해야함
				$(".cover-slider").find("ul").height( $sliderItems.eq($num).height() );
				
			}//itemsLength > 1
		});
	}//coverSlider() End

	function coverMasonry(){
		var $masonry = $(".cover-masonry");

		$.getScript( "//unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js", function( data, textStatus, jqxhr ) {
			$masonry.each(function(){
				var $this = $(this);

				$this.find("ul").css({
					"display": "block",
				}).masonry({
					itemSelector: '.cover-masonry ul li',
					columnWidth: '.cover-masonry ul li',
				});
			});
		});
	}

	function getCookie(name){
		name = new RegExp(name + '=([^;]*)');
		return name.test(document.cookie) ? unescape(RegExp.$1) : '';
	}

	function postListType(){
		var cookie = document.cookie;

		if ( !getCookie('post-type') && !$("body").hasClass("post-type-thumbnail") ){
			$(".post-header .list-type .list").addClass("current");
		}

		if ( $("body").hasClass("post-type-thumbnail") ){
			$(".post-header .list-type .thum").addClass("current").siblings().removeClass("current");
		} else {
			$(".post-header .list-type .list").addClass("current").siblings().removeClass("current");
		}
	}

	function viewMore(){
		if ( $(".paging-view-more").length && $(".post-item").length ){
			if ( $(".paging-view-more").length && $(".post-item").length ){
				viewMoreShow();
			}

			function viewMoreShow(){
				var nextUrl = $(".pagination .next").attr("href");
				$(".pagination a").hide();
				if( nextUrl ){
					$(".pagination .inner").append('<a href="'+nextUrl+'" class="btn view-more">더보기 <i class="fas fa-th"></i></a>');
					$(".pagination .view-more").on("click", function(){
						viewMore(nextUrl);
						return false;
					});
				}
			}

			function viewMore(url){
				$.ajax({
					url: url
				}).done(function (res) {
					var $res = $(res),
							$nextPostItem = $res.find(".post-item"),
							$paginationInner = $res.find(".pagination").html();
					if ( $nextPostItem.length > 0 ){
						$("#content > .inner").append($nextPostItem);
						$(".pagination").html($paginationInner);
						setNoImage();						
						viewMoreShow();
					} else {
						$(".pagination").remove();
					}
				});
			}
		} else {
			var current_num = $(".pagination .selected").text(),
				total_num = $(".pagination .next").length ? $(".pagination .next").prev().text() : $(".pagination a:last").text();

			$(".pagination .inner").append('<span class="current">'+current_num+'/'+total_num+'</span>');
			$(".pagination .inner .current").css('color',$(".title h1 a").css('color'));
		}
	}

	function mobileTable(){
		var $table = $(".entry-content table");

		if( $table.length > 0 ){
			$table.each(function(){
				if ( $(this).css("table-layout") == "fixed" && !$(this).parent().hasClass("table-wrap") ){
					$(this).wrap('<div class="table-wrap"></div>');
				}
			});
		}
	}

	function iframeWrap(){
		var $iframe = $(".entry-content iframe");

		if( $iframe.length > 0 ){
			$iframe.each(function(){
				if ( !$(this).parent().hasClass("iframe-wrap") ){
					$(this).wrap('<div class="iframe-wrap"></div>');
				}
			});
		}
	}

	gnb();
	

	if ( $(".cover-slider").length ){
		coverSlider();
	}
	
	
	if ( $(".cover-masonry").length ) coverMasonry();
	if ( $(".post-header .list-type").length ) postListType();
	if ( $(".pagination").length ) viewMore();
	if ( $(".entry-content").length ){
		mobileTable();
		iframeWrap();
	}

	$(window).resize(function(){
		checkMobile();
		mobileTable();
		setMobileCategory();
		if($is_mobile){
			if($(window).scrollTop() > 100){
				$('.nav').addClass('on');
			}
		}else{
			if($('.nav.on').length){
				$('.nav').removeClass('on');
			}
		}
		$('.mobile-menu.on').click();		
	});

	if($is_mobile && $(".post-item").length > 0){
		//모바일이면 뷰포트 호버 온
		$.fn.isInViewport = function() {
			var elementTop = $(this).offset().top;
			var elementBottom = elementTop + $(this).outerHeight();
		
			var viewportTop = $(window).scrollTop()+200;
			var viewportBottom = viewportTop + $(window).height()-550;
			return elementBottom > viewportTop && elementTop < viewportBottom;
		};		
	}

	//모바일기기체크 - @media로 체크
	function checkMobile(){
		if( $('.mobile-menu').css('display')=='block') {
			$is_mobile = true;
			$('#sidebar').detach().appendTo('nav#gnb');
		}else{
			$is_mobile = false;
			$('#sidebar').detach().prependTo('#wrap .container');
		}
	}
	function setNoImage(){
		$(".post-item").each(function(){
			if(!$(this).find('.thum img').length){
				$(this).find('.thum').append('<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAACCAQAAAA3fa6RAAAADklEQVR42mNkAANGCAUAACMAA2w/AMgAAAAASUVORK5CYII=">');
				$(this).addClass('noimage');
			}
		})	
	}

	function setMobileCategory(){
		if($('#header .category-menu').css('display') == 'none' || bSidebarCategory){
			if($('.category-menu > .inner > .category').length){
				$('#wrap_etc').prepend($('<div id="mobile_category" class="box_aside"><div class="tit_aside">Category</div></div>'));
				$('.category-menu > .inner > .category').detach().appendTo('#mobile_category');
			}else{
				$('#header .category').css('display','block');
			}
		}else{
			if($('#wrap_etc > #mobile_category').length){
				$('#mobile_category .category').detach().prependTo('.category-menu > .inner');
				$('#mobile_category').remove();
			}
		}
	}

	if($('.btn-top').length){
		$('.btn-top').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 600);
			return false;
		});
	}

})(jQuery);
